# 模型文件
SBERT从[从此处下载](https://pan.baidu.com/s/16GKek3RZHoqSNVzGZ03vZg)
提取码：4wc8
